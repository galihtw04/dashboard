<?php 
/**
 * DashboardBuilder
 *
 * @author Diginix Technologies www.diginixtech.com
 * Support <support@dashboardbuider.net> - https://www.dashboardbuilder.net
 * @copyright (C) 2016-2023 Dashboardbuilder.net
 * @version 6.3
 * @license: Must read and agree LICENSE.txt before use.
 */

define('FOLDER', "../");
define("DATA",FOLDER."data/");
define("STORE",FOLDER."store/");